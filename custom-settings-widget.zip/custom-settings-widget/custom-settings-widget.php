<?php
/*
Plugin Name: Custom Settings and Widget Page
Description: A custom plugin to create a settings and widget page in the WordPress admin.
Version: 1.0.0
Author: Name
Text Domain: custom-settings-widget
*/

if (!defined('ABSPATH')) {
    exit;
}

// Activation hook
function custom_settings_widget_activate() {
    // You can add functionality to be executed upon plugin activation here.
}
register_activation_hook(__FILE__, 'custom_settings_widget_activate');

// Deactivation hook
function custom_settings_widget_deactivate() {
   flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'custom_settings_widget_deactivate');

// Include the admin settings page class
if (is_admin()) {
    require_once plugin_dir_path(__FILE__) . 'inc/class-admin-settings-menu.php';
    new Admin_Settings_Widget();
}

// Register the widget using widgets_init action hook
require_once plugin_dir_path(__FILE__) . 'inc/class-admin-settings-widget.php';
add_action('widgets_init', 'register_custom_widgets');
function register_custom_widgets() {
    register_widget('Wpd_Ws_Example_Widget');
}
function custom_settings_widget_load_textdomain() {
    load_plugin_textdomain( 'custom-settings-widget', false, basename( dirname( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'custom_settings_widget_load_textdomain' );

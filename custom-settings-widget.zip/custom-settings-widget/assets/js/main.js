jQuery(document).ready(function($) {
    // Handle media uploader
    var mediaUploader;
    $('.image-upload-button').click(function(e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            }, 
            multiple: false
        });
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#image').val(attachment.url);
        });
        mediaUploader.open();
    });

    // Initialize color picker
    $('.color-field').wpColorPicker();
});

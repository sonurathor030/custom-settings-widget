<?php

if (!defined('ABSPATH')) {

    exit;

}



class Wpd_Ws_Example_Widget extends WP_Widget
{



    public function __construct()
    {

        parent::__construct(

            'wpd_ws_example_widget',

            __('Wpd Ws Example Widget', 'custom-settings-widget'),

            array('description' => __('An example widget with form fields', 'custom-settings-widget'))

        );

        add_action('widgets_init', function () {
            register_widget('Wpd_Ws_Example_Widget');
        });
    }


    public $args = array(
        'before_title' => '<h4 class="widgettitle">',
        'after_title' => '</h4>',
        'before_widget' => '<div class="widget-wrap">',
        'after_widget' => '</div>',
    );
    // Output the widget on the frontend by loading a separate file

    public function widget($args, $instance)
    {

        echo $args['before_widget'];



        if (!empty($instance['title'])) {

            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];

        }

        // Load the frontend display from a separate file

        $first_name = !empty($instance['first_name']) ? esc_html($instance['first_name']) : '';

        $last_name = !empty($instance['last_name']) ? esc_html($instance['last_name']) : '';
        $sex = !empty($instance['sex']) ? esc_html($instance['sex']) : 'Male';

        echo "<p>Hello, My Name is " . $first_name . " " . $last_name . "</p>";
        if (!empty($instance['display_sex'])) {
            echo "<p>Sex: " . $sex . "</p>";
        }
        
        echo $args['after_widget'];

    }



    // Output the widget form in the admin

    public function form($instance)
    {

        // Default values

        $title = !empty($instance['title']) ? $instance['title'] : __('Demo widget', 'custom-settings-widget');

        $first_name = !empty($instance['first_name']) ? $instance['first_name'] : '';

        $last_name = !empty($instance['last_name']) ? $instance['last_name'] : '';

        $sex = !empty($instance['sex']) ? $instance['sex'] : 'Male';

        $display_sex = isset($instance['display_sex']) ? (bool) $instance['display_sex'] : false;



        $error_message = isset($instance['error_message']) ? $instance['error_message'] : '';



        // If there are errors, display them

        if ($error_message) {

            echo "<p style='color: red;'>" . esc_html($error_message) . "</p>";

        }

        ?>

        <p>

            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'custom-settings-widget'); ?></label>

            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">

        </p>

        <p>

            <label
                for="<?php echo $this->get_field_id('first_name'); ?>"><?php _e('First Name:', 'custom-settings-widget'); ?></label>

            <input class="widefat" id="<?php echo $this->get_field_id('first_name'); ?>"
                name="<?php echo $this->get_field_name('first_name'); ?>" type="text"
                value="<?php echo esc_attr($first_name); ?>">

        </p>

        <p>

            <label
                for="<?php echo $this->get_field_id('last_name'); ?>"><?php _e('Last Name:', 'custom-settings-widget'); ?></label>

            <input class="widefat" id="<?php echo $this->get_field_id('last_name'); ?>"
                name="<?php echo $this->get_field_name('last_name'); ?>" type="text"
                value="<?php echo esc_attr($last_name); ?>">

        </p>

        <p>

            <label for="<?php echo $this->get_field_id('sex'); ?>"><?php _e('Sex:', 'custom-settings-widget'); ?></label>

            <select class="widefat" id="<?php echo $this->get_field_id('sex'); ?>"
                name="<?php echo $this->get_field_name('sex'); ?>">

                <option value="Male" <?php selected($sex, 'Male'); ?>><?php _e('Male', 'custom-settings-widget'); ?></option>

                <option value="Female" <?php selected($sex, 'Female'); ?>><?php _e('Female', 'custom-settings-widget'); ?>
                </option>

            </select>

        </p>

        <p>

            <input class="checkbox" type="checkbox" <?php checked($display_sex); ?>
                id="<?php echo $this->get_field_id('display_sex'); ?>"
                name="<?php echo $this->get_field_name('display_sex'); ?>" />

            <label
                for="<?php echo $this->get_field_id('display_sex'); ?>"><?php _e('Display sex publicly?', 'custom-settings-widget'); ?></label>

        </p>

        <?php

    }



    // Sanitize and validate form values

    public function update($new_instance, $old_instance) {
        $instance = array();
    
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['first_name'] = (!empty($new_instance['first_name'])) ? sanitize_text_field($new_instance['first_name']) : '';
        $instance['last_name'] = (!empty($new_instance['last_name'])) ? sanitize_text_field($new_instance['last_name']) : '';
        $instance['sex'] = (!empty($new_instance['sex'])) ? sanitize_text_field($new_instance['sex']) : 'Male';
        $instance['display_sex'] = !empty($new_instance['display_sex']) ? 1 : 0;
    
        // Server-side validation
        if (empty($instance['first_name']) || empty($instance['last_name'])) {
            // Store the error message in a different way
            $instance['error_message'] = __('First Name and Last Name are required.', 'custom-settings-widget');
        } else {
            $instance['error_message'] = '';
        }
    
        return $instance;
    }
    

}


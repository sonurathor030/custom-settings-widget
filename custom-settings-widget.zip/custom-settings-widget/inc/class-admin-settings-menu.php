<?php
if (!defined('ABSPATH')) {
    exit;
}

class Admin_Settings_Widget {

    private $options;

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'handle_reset_action'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    public function add_settings_page() {
        add_menu_page(
            __('WP Settings & Widget Page', 'custom-settings-widget'),
            __('WP Settings & Widget Page', 'custom-settings-widget'),
            'manage_options',
            'custom-settings-widget',
            array($this, 'admin_widget_settings_callback'),
            'dashicons-admin-generic'
        );
    }

    public function admin_widget_settings_callback() {
        // Get option values
        $this->options = get_option('custom_settings_options');
        ?>
        <div class="wrap">
            <h1><?php _e('WP Settings & Widget Page', 'custom-settings-widget'); ?></h1>
            <?php settings_errors('custom_settings_options');  ?>
            <form method="post" action="">
                <?php
                // Add nonce field for security
                wp_nonce_field('reset_all_settings', 'reset_all_settings_nonce');
                ?>
                <input type="submit" name="reset_all_settings" class="button button-primary" value="<?php _e('Reset All Settings', 'custom-settings-widget'); ?>" />
            </form>
            <form method="post" action="options.php" class="main-form">
                <?php
                settings_fields('custom_settings_group');
                submit_button();
                do_settings_sections('custom-settings-widget');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function handle_reset_action() {
        if (isset($_POST['reset_all_settings']) && check_admin_referer('reset_all_settings', 'reset_all_settings_nonce')) {
            delete_option('custom_settings_options');
            // Redirect to avoid resubmission on page refresh
            wp_redirect(admin_url('admin.php?page=custom-settings-widget'));
            exit;
        }
    }

    public function register_settings() {
        register_setting('custom_settings_group', 'custom_settings_options', array($this, 'sanitize'));

        add_settings_section(
            'custom_settings_section',
            __('WP Settings & Widget Page', 'custom-settings-widget'),
            array($this, 'print_section_info'),
            'custom-settings-widget'
        );

        add_settings_field(
            'title',
            __('Title', 'custom-settings-widget'),
            array($this, 'title_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );

        add_settings_field(
            'description',
            __('Description', 'custom-settings-widget'),
            array($this, 'description_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );

        add_settings_field(
            'editor_content',
            __('Editor Content', 'custom-settings-widget'),
            array($this, 'editor_content_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );

        add_settings_field(
            'date',
            __('Date', 'custom-settings-widget'),
            array($this, 'date_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );

        add_settings_field(
            'image',
            __('Image', 'custom-settings-widget'),
            array($this, 'image_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );

        add_settings_field(
            'color_picker',
            __('Color Picker', 'custom-settings-widget'),
            array($this, 'color_picker_callback'),
            'custom-settings-widget',
            'custom_settings_section'
        );
    }

    public function sanitize($input) {
        $sanitized_input = array();
        if (empty($input['title'])) {
            add_settings_error('custom_settings_options', 'invalid_title', __('Title is required.', 'custom-settings-widget'));
            $sanitized_input['title'] = '';
        } else {
            $sanitized_input['title'] = sanitize_text_field($input['title']);
        }
    
        if (empty($input['description'])) {
            add_settings_error('custom_settings_options', 'invalid_description', __('Description is required.', 'custom-settings-widget'));
            $sanitized_input['description'] = '';
        } else {
            $sanitized_input['description'] = sanitize_textarea_field($input['description']);
        }

        $sanitized_input['editor_content'] = wp_kses_post($input['editor_content']);
        $sanitized_input['date'] = sanitize_text_field($input['date']);
        $sanitized_input['image'] = esc_url_raw($input['image']);
        $sanitized_input['color_picker'] = sanitize_hex_color($input['color_picker']);

        return $sanitized_input;
    }

    public function print_section_info() {
    }

    public function title_callback() {
        printf(
            '<input type="text" id="title" name="custom_settings_options[title]" class="title" value="%s" />',
            isset($this->options['title']) ? esc_attr($this->options['title']) : ''
        );
    }

    public function description_callback() {
        printf(
            '<textarea id="description" name="custom_settings_options[description]" rows="5" cols="73">%s</textarea>',
            isset($this->options['description']) ? esc_attr($this->options['description']) : ''
        );
    }

    public function editor_content_callback() {
        $content = isset($this->options['editor_content']) ? esc_attr($this->options['editor_content']) : '';
        // Customize the settings for the wp_editor
        $editor_settings = array(
            'textarea_name' => 'custom_settings_options[editor_content]',
            'textarea_rows' => 10, // Number of rows for the textarea
            'editor_class' => 'custom-editor-class', // Custom class for additional CSS styling if needed
        );

        wp_editor($content, 'editor_content', $editor_settings);
    }

    public function date_callback() {
        printf(
            '<input type="date" id="date" name="custom_settings_options[date]" value="%s" />',
            isset($this->options['date']) ? esc_attr($this->options['date']) : ''
        );
    }

    public function image_callback() {
        printf(
            '<input type="text" id="image" name="custom_settings_options[image]" value="%s" />',
            isset($this->options['image']) ? esc_attr($this->options['image']) : ''
        );
        echo '<input type="button" class="button image-upload-button" value="' . __('Choose Image', 'custom-settings-widget') . '" />';
    }

    public function color_picker_callback() {
        printf(
            '<input type="text" id="color_picker" name="custom_settings_options[color_picker]" class="color-field" value="%s" />',
            isset($this->options['color_picker']) ? esc_attr($this->options['color_picker']) : ''
        );
    }
    
    public function enqueue_admin_scripts() {
        wp_enqueue_media();
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_style('wp-color-picker');

        // Add a custom JS script for handling the image uploader
        wp_enqueue_style('custom-settings-widget-style', plugin_dir_url(__FILE__) . '../assets/css/style.css');
        wp_enqueue_script('custom-settings-widget-js', plugin_dir_url(__FILE__) . '../assets/js/main.js', array('jquery', 'wp-color-picker'), null, true);
    }
}
